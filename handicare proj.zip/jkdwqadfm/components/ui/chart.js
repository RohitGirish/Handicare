// components/ui/chart.js
// Bare minimum Chart.js wrapper to satisfy the import

export const Chart = window.Chart
